# Pixel Playground

A responsive starter website featuring:
- Sign-in / account creation demo
- Home dashboard and local streak counter
- Mini-game arcade: Colour Memory and Tic-Tac-Toe
- Daily five-letter Wordle-style puzzle
- Local demo chat
- Admin studio visible when signed in with the username `Somkene`
- Admin control to choose the daily word and clear demo chat

## Run it
Unzip the folder and open `index.html` in a modern browser. No build step is needed.

## Important limitations
This is a front-end prototype. Accounts, passwords, chat, streaks, and the daily word are stored in the current browser's `localStorage`; they are not shared between devices or different visitors. The demo password is not securely hashed. The username-only admin check is not secure and can be bypassed by a technically skilled visitor. Do not use this version for real users or private information.

For a real public website, connect a backend (for example, Supabase or Firebase) for secure authentication, server-enforced admin permissions, shared chat, persistent user profiles, moderation, and a server-managed daily Wordle answer. Store password credentials only through a trusted authentication provider. Add moderation/reporting tools and privacy rules before opening chat to the public.
