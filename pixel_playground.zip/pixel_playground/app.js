(() => {
  const $ = (id) => document.getElementById(id);
  const today = () => new Date().toISOString().slice(0,10);
  const get = (key, fallback) => { try { const x = localStorage.getItem(key); return x === null ? fallback : JSON.parse(x); } catch { return fallback; } };
  const set = (key, value) => localStorage.setItem(key, JSON.stringify(value));
  let currentUser = get('pp_currentUser', '');
  let accounts = get('pp_accounts', {});
  let stats = get('pp_stats', {});
  let messages = get('pp_messages', []);
  let dailyWord = get('pp_dailyWord', 'PIXEL').toUpperCase();
  let wordle = get('pp_wordle', {});
  let memorySequence = [], memoryStep = 0, memoryInput = [], memoryLocked = false;
  let ttt = Array(9).fill(''), tttTurn = 'X', tttDone = false;

  function userStats() {
    if (!currentUser) return {streak:0,lastDay:'',games:0,solved:[]};
    if (!stats[currentUser]) stats[currentUser] = {streak:0,lastDay:'',games:0,solved:[]};
    return stats[currentUser];
  }
  function saveStats() { set('pp_stats', stats); updateDashboard(); }
  function markActivity() {
    if (!currentUser) return;
    const s = userStats(), d = today();
    if (s.lastDay !== d) {
      const prev = new Date(Date.now() - 86400000).toISOString().slice(0,10);
      s.streak = s.lastDay === prev ? s.streak + 1 : 1;
      s.lastDay = d;
    }
    s.games += 1; saveStats();
  }
  function updateDashboard() {
    const s = userStats();
    $('streakCount').textContent = `${s.streak || 0} day${s.streak === 1 ? '' : 's'}`;
    $('gamesCount').textContent = s.games || 0;
    $('wordleStatus').textContent = wordle[today()]?.status === 'won' ? 'Solved!' : wordle[today()]?.status === 'lost' ? 'Try tomorrow' : 'Not played';
    $('adminChatCount').textContent = messages.length;
    $('adminGamesCount').textContent = s.games || 0;
  }
  function renderAccount() {
    $('userLabel').textContent = currentUser ? `Hi, ${currentUser}` : 'Not signed in';
    $('signInBtn').classList.toggle('hidden', !!currentUser);
    $('signOutBtn').classList.toggle('hidden', !currentUser);
    $('authPanel').classList.toggle('hidden', !!currentUser);
    $('adminNav').classList.toggle('hidden', currentUser.toLowerCase() !== 'somkene');
    if (currentUser) $('authMessage').textContent = '';
    updateDashboard(); renderWordle(); renderChat();
  }
  function showView(name) {
    if (!currentUser) { $('authPanel').classList.remove('hidden'); return; }
    document.querySelectorAll('.view').forEach(v => v.classList.add('hidden'));
    $(name+'View').classList.remove('hidden');
    document.querySelectorAll('.nav-btn').forEach(b => b.classList.toggle('active', b.dataset.view === name));
    if (name === 'admin' && currentUser.toLowerCase() !== 'somkene') showView('home');
    if (name === 'wordle') renderWordle();
    if (name === 'chat') renderChat();
    if (name === 'admin') $('dailyWordInput').value = dailyWord;
  }
  document.querySelectorAll('[data-view]').forEach(b => b.addEventListener('click', () => showView(b.dataset.view)));
  document.querySelectorAll('[data-go]').forEach(b => b.addEventListener('click', () => showView(b.dataset.go)));
  $('signInBtn').addEventListener('click', () => { $('authPanel').classList.remove('hidden'); $('usernameInput').focus(); });
  $('signOutBtn').addEventListener('click', () => { currentUser=''; set('pp_currentUser',''); renderAccount(); document.querySelectorAll('.view').forEach(v=>v.classList.add('hidden')); });
  $('authForm').addEventListener('submit', e => {
    e.preventDefault();
    const name = $('usernameInput').value.trim(), pass = $('passwordInput').value;
    if (!/^[a-zA-Z0-9_]{3,20}$/.test(name)) { $('authMessage').textContent = 'Use 3–20 letters, numbers or underscores.'; return; }
    const key = name.toLowerCase();
    // Prototype only: this stores credentials in this browser. Never use this for real accounts.
    if (accounts[key] && accounts[key].password !== pass) { $('authMessage').textContent = 'That username already exists with a different password.'; return; }
    if (!accounts[key]) accounts[key] = {username:name,password:pass};
    set('pp_accounts', accounts);
    currentUser = accounts[key].username; set('pp_currentUser', currentUser);
    renderAccount(); showView('home');
  });

  // Daily Wordle
  function getWordleState() {
    if (!wordle[today()]) wordle[today()] = {guesses:[],status:'playing'};
    return wordle[today()];
  }
  function renderWordle() {
    const board = $('wordleBoard'); if (!board) return;
    board.innerHTML = '';
    const state = getWordleState();
    for (let r=0;r<6;r++) {
      const guess = state.guesses[r] || '';
      const result = guess ? evaluateGuess(guess, dailyWord) : [];
      for (let c=0;c<5;c++) {
        const cell=document.createElement('div'); cell.className='wordle-cell';
        cell.textContent=guess[c] || '';
        if (result[c]) cell.classList.add(result[c]);
        board.appendChild(cell);
      }
    }
    $('guessInput').disabled = state.status !== 'playing';
    $('wordleForm').querySelector('button').disabled = state.status !== 'playing';
    $('wordleMessage').textContent = state.status === 'won' ? 'Brilliant! You solved today’s word 🎉' : state.status === 'lost' ? `Good try! Today's word was ${dailyWord}.` : `${state.guesses.length} of 6 guesses used.`;
    set('pp_wordle', wordle);
    updateDashboard();
  }
  function evaluateGuess(guess, answer) {
    const result = Array(5).fill('absent'), remaining = answer.split('');
    for(let i=0;i<5;i++) if(guess[i]===answer[i]) { result[i]='correct'; remaining[i]=null; }
    for(let i=0;i<5;i++) if(result[i]!=='correct') { const idx=remaining.indexOf(guess[i]); if(idx>=0){result[i]='present';remaining[idx]=null;} }
    return result;
  }
  $('wordleForm').addEventListener('submit', e => {
    e.preventDefault(); if (!currentUser) return;
    const guess = $('guessInput').value.trim().toUpperCase();
    if (!/^[A-Z]{5}$/.test(guess)) { $('wordleMessage').textContent='Enter exactly five letters.'; return; }
    const state=getWordleState(); if(state.status!=='playing') return;
    state.guesses.push(guess); $('guessInput').value='';
    if(guess===dailyWord) { state.status='won'; markActivity(); }
    else if(state.guesses.length>=6) state.status='lost';
    set('pp_wordle',wordle); renderWordle();
  });
  $('wordleReset').addEventListener('click', () => {
    if (!currentUser) return;
    wordle[today()]={guesses:[],status:'playing'}; set('pp_wordle',wordle); renderWordle();
  });

  // Admin-only controls. Real permissions must be checked by a server.
  $('dailyWordForm').addEventListener('submit', e => {
    e.preventDefault();
    if(currentUser.toLowerCase()!=='somkene') return;
    const val=$('dailyWordInput').value.trim().toUpperCase();
    if(!/^[A-Z]{5}$/.test(val)){ $('adminMessage').textContent='Please enter exactly five letters.'; return; }
    dailyWord=val; set('pp_dailyWord',dailyWord); wordle[today()]={guesses:[],status:'playing'}; set('pp_wordle',wordle);
    $('adminMessage').textContent=`Today's word has been set to ${dailyWord}.`; renderWordle();
  });
  $('clearChatBtn').addEventListener('click', () => {
    if(currentUser.toLowerCase()!=='somkene') return;
    messages=[]; set('pp_messages',messages); renderChat(); $('moderationMessage').textContent='Demo chat cleared.';
  });

  // Local demo chat
  function renderChat() {
    const box=$('chatMessages'); if(!box) return;
    box.innerHTML='';
    if(!messages.length){const p=document.createElement('p');p.className='muted';p.textContent='No messages yet. Start the conversation!';box.appendChild(p);}
    messages.forEach(m=>{
      const el=document.createElement('div');el.className='chat-message'+(m.user===currentUser?' mine':'');
      const strong=document.createElement('strong');strong.textContent=m.user;
      const p=document.createElement('p');p.textContent=m.text;
      const time=document.createElement('time');time.textContent=m.time;
      el.append(strong,p,time);box.appendChild(el);
    });
    box.scrollTop=box.scrollHeight;
  }
  $('chatForm').addEventListener('submit', e => {
    e.preventDefault(); if(!currentUser)return;
    const text=$('chatInput').value.trim(); if(!text)return;
    messages.push({user:currentUser,text,time:new Date().toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'})});
    messages=messages.slice(-100);set('pp_messages',messages);$('chatInput').value='';renderChat();updateDashboard();
  });

  // Tic-tac-toe
  function renderTTT() {
    const board=$('tttBoard'); board.innerHTML='';
    ttt.forEach((v,i)=>{const b=document.createElement('button');b.className='ttt-cell';b.textContent=v;b.setAttribute('aria-label',`Square ${i+1} ${v}`);b.addEventListener('click',()=>{if(tttDone||ttt[i])return;ttt[i]=tttTurn;const win=[[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]].some(line=>line.every(j=>ttt[j]===tttTurn));if(win){tttDone=true;$('tttMessage').textContent=`${tttTurn} wins!`;markActivity();}else if(ttt.every(Boolean)){tttDone=true;$('tttMessage').textContent='It’s a draw!';}else{tttTurn=tttTurn==='X'?'O':'X';$('tttMessage').textContent=`${tttTurn}'s turn.`;}renderTTT();});board.appendChild(b);});
  }
  $('tttReset').addEventListener('click',()=>{ttt=Array(9).fill('');tttTurn='X';tttDone=false;$('tttMessage').textContent='X goes first.';renderTTT();});

  // Colour memory: sequence shown, then player repeats it.
  const colours=['🟣','🟠','🟢','🔵'];
  function drawMemory() {
    const box=$('memoryGame');box.innerHTML='';
    colours.forEach((c,i)=>{const b=document.createElement('button');b.className='memory-tile';b.textContent=c;b.addEventListener('click',()=>memoryPick(i,b));box.appendChild(b);});
  }
  function flashSequence() {
    memoryLocked=true;const tiles=[...document.querySelectorAll('.memory-tile')];
    memorySequence.forEach((idx,step)=>setTimeout(()=>{tiles[idx].classList.add('lit');setTimeout(()=>tiles[idx]?.classList.remove('lit'),360);if(step===memorySequence.length-1)setTimeout(()=>{memoryLocked=false;$('memoryMessage').textContent='Your turn — repeat the sequence!';},450);},step*650));
  }
  function memoryPick(i,b) {
    if(memoryLocked||!memorySequence.length)return;
    b.classList.add('lit');setTimeout(()=>b.classList.remove('lit'),180);
    memoryInput.push(i);
    if(memoryInput[memoryInput.length-1]!==memorySequence[memoryInput.length-1]){$('memoryMessage').textContent='Not quite — try a new round!';memorySequence=[];memoryInput=[];return;}
    if(memoryInput.length===memorySequence.length){$('memoryMessage').textContent='Nice! Sequence complete. +1 round';markActivity();memorySequence.push(Math.floor(Math.random()*4));memoryInput=[];setTimeout(flashSequence,700);}
  }
  $('memoryStart').addEventListener('click',()=>{memorySequence=[Math.floor(Math.random()*4)];memoryInput=[];$('memoryMessage').textContent='Watch carefully…';drawMemory();setTimeout(flashSequence,450);});

  renderAccount();drawMemory();renderTTT();
  if(currentUser) showView('home');
})();